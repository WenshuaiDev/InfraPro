# 四机生产联合备份与恢复

本包适配 2026-11-19 的 schema 59 兼容部署。152 每晚使用原有 `infrapro-backup.timer`，北京时间 03:00 起一分钟内触发。程序仍通过原备份专用 SSH 身份连接 37、151、38。38 上的现有业务、数据库、对象、用户和授权密钥保持原状。

## 安装

升级前的 schema 55 检查点须由**原协调器和原三台助手**完整完成，先记录 38 返回的字节数与 SHA-256 以及 152 的 `data/backups/latest.json`。在本次发布维护窗口内，待旧备份服务退出后，由部署负责人传送并校验 `backup-tools-20261119.tar.gz`。用受保护目录解压。先在 37、151、38 分别安装相应编号，最后安装 152 并恢复原有 timer。

```sh
sudo /usr/bin/python3 ./backup-tools/install.py --host 37
sudo /usr/bin/python3 ./backup-tools/install.py --host 151
sudo /usr/bin/python3 ./backup-tools/install.py --host 38
sudo /usr/bin/python3 ./backup-tools/install.py --host 152
```

每一行分别在编号对应的主机执行一次。安装器核对 `config/environment.json` 中的本机地址，逐文件核验包内 SHA-256。152 复用现有备份锁。在 152 的兼容部署中，`config/architecture/maintenance-events.json` 以应用文件属主和 0600 权限保存，`mode=pg` 供管理 CLI 读取事件代次。原有应用单元继续按本次发布的兼容方式运行。

| 主机 | 位置和权限 | 用途 |
| --- | --- | --- |
| 四台 | `/usr/local/libexec/infrapro-checkpoint-59-20261119/`，root 所有，目录 0755，Python、SQL 和清单 0644 | 匹配已选发行的恢复器、角色发现、对象归档、角色清单、四组恢复 DCL 与组身份 |
| 152 | `/usr/local/libexec/infrapro-production-backup`，root:root 0755 | 原 systemd oneshot 的兼容入口 |
| 37、151、38 | 原备份公钥的 SSH forced command 指向的程序，root:root 0755 | 安装器按公钥指纹和 152 的来源限制确定实际地址，保留既有 SSH 限制和 sudo 规则 |
| 152 | `/usr/local/libexec/infrapro-architecture-restore`，root:root 0755 | 读取完整检查点；恢复和开放使用单独的目标配置与管理员身份 |
| 每台 | `/var/backups/infrapro-checkpoint-tools/20261119-b09feb944c39/<主机编号>/`，root 私有 | 首次替换前的既有入口、SHA-256、安装收据及实际路径 |

新协调器向各机按阶段请求冻结，由各机按实际单元保存先前 active/inactive 状态，再依序恢复。152 的 root oneshot 控制本机业务单元。151 的普通备份账号沿用现有的 `infrapro-ingest-relay.service` 精确停止/启动权限，38 沿用同样限定于 `infrapro-diagnostics.service` 的权限。37 的现有部署没有需停止的业务写入程序。数据库、Keeper、ClickHouse、S3 和 Nginx 保持服务。若需回到 schema 55 的运维工具，在协调器停车且 timer 暂停时从各机私有回滚目录恢复**同一代的全部四个入口**。旧检查点随对应旧发行及其原恢复资料保存。

## 每日归档内容

- 业务 PG/relay PG、ClickHouse 原生备份、四类对象与摘要、收据和 ACK 边界、文件封存、审计 hold 及清单、大屏固定文件清单。
- schema 59 的 `event-watermarks.json` 来自实际 `event-relay status`，包含事件恢复代次及分派所有权。兼容模式通过 PostgreSQL 查询。联合恢复继续使用受限元数据函数及发行附带的四组 DCL。
- 所有节点原有 `config/`、`units/` 和 `ops/`，38 的独立诊断状态，以及 151 的 relay dump 与 manifest。152 的整棵 `releases/` 同时包含选定二进制、全部保留旧版、站点控制台和实际解析包。152 的 `config/app/mfa-keyring.json` 及 `config/backup-access`、本机 TLS、受保护的诊断/观察器配置按原物理字节归档。离线保存的 CA 签发私钥仍由其原保管渠道管理。
- 每份 `node-<编号>.tar.gz` 内新增权限为 0600 的 `site-checkpoint-materials.json`。它记录节点配置摘要和数字属主；152 另记原 MFA 密钥环的摘要、活跃及历史 key ID、核心发行清单、站点入口及两种解析清单。密钥本身只随节点内的私有原文件归档。每份节点归档也带 `installed-checkpoint-tools/`，包含可恢复的完整工具、SQL 与 SHA-256。
- 38 仓库保留最近两份完整且回读通过的包，原 300 GiB 容量、20% 空闲阈值和 8 MiB/s 传输限制继续生效。成功时检查 152 的 `data/backups/latest.json` 中的 `state`、`release`、`repository.archive_verified`、`repository.sha256` 与 `completed_at`。失败时保留上次成功点与新失败目录。先查看 `journalctl -u infrapro-backup.service`、`checkpoint.json` 的 phase 及 writer 记录；文件备份未能 seal 时，用同一备份 ID 处理文件冻结。

## 联合恢复

1. 通过原备份账号从 38 取回已核验包，比对接收回执中的 SHA-256，向权限 0700 的独立工作目录解开。子目录 `checkpoint-…/` 的 `archive-manifest.json` 应从该可信外层归档取得。使用 `infrapro-architecture-restore verify --checkpoint <检查点目录> --manifest-sha256 <清单摘要>` 只读核对归档和四机冻结边界。
2. 准备与生产隔离的空业务/relay PG、ClickHouse 数据库、各域对象桶、独立的诊断件目录及认证材料。取出节点 152 的 `config/app/mfa-keyring.json` 以原数字属主和 0600 放入目标保护配置，按 `site-checkpoint-materials.json` 比对 SHA-256；旧账号的 TOTP/恢复材料依赖同一组密钥。保留原始四节点归档，目标重新签发网络/TLS 和应用凭据。解析恢复使用归档中本次 `20261119-b09feb944c39-site/parser-package`，其不可变方法包来自原现场。
3. 以 `four-host-restore.example.json` 为模板填写目标绝对路径。四个 writer 条目须来自实际目标本次冻结；38 对应独立诊断 bbolt 和目标 server 配置。数据库工具使用 PG17。原生 `pg_restore` 走标准 PATH；仅在原 PG17 `public` schema 预建的恢复环境需要时，可把提供的 `restore-pg-restore.py` 安装到**目标环境专属** PATH 前缀并命名为 `pg_restore`，保留真实二进制在目标操作用户的 `~/env/infrapro/bin/pg_restore`。
4. 对独立目标执行 `infrapro-architecture-restore apply --checkpoint <检查点目录> --manifest-sha256 <清单摘要> --target <私有目标配置> --reason <原因>`。恢复器核对空目标，恢复 PG/CH/对象、固定文件、空间内容、relay 收据及解析包，轮换恢复代次，重新安装 schema 59 的授权，并验证目标诊断状态和域内容。检查目标 `recovery.json` 达到 `verified_read_only` 及必要证据后，操作人使用同一参数运行 `open`，再按恢复的目标服务清单开放。

本目录为本地组装材料，后续安装状态与每日检查点以生产主机的安装收据、timer 和仓库接收回执为准。
