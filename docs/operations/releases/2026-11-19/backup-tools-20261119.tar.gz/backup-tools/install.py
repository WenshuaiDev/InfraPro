#!/usr/bin/python3
"""Install the four-host checkpoint tools locally on one explicitly identified host."""

import argparse
import base64
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import shlex
import shutil
import stat
import tempfile


HERE = Path(__file__).resolve().parent
SRC = HERE / "payload" if (HERE / "payload/package.json").is_file() else HERE
PKG = Path("/usr/local/libexec/infrapro-checkpoint-59-20261119")
DEST = Path("/usr/local/libexec")
HOSTS = {"37": ("gzzx", "10.23.56.37"), "151": ("uadmin", "10.23.52.151"),
         "152": ("uadmin", "10.23.52.152"), "38": ("gzzx", "10.23.56.38")}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def end(message):
    raise SystemExit(message)


def put(path, data, mode, owner=(0, 0)):
    if path.is_symlink():
        end("Refusing symlink destination: " + str(path))
    if path.is_file():
        st = path.stat()
        if path.read_bytes() == data and stat.S_IMODE(st.st_mode) == mode and (st.st_uid, st.st_gid) == owner:
            return
    fd, temporary = tempfile.mkstemp(prefix=".infrapro-backup-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as out:
            out.write(data)
            out.flush()
            os.fchown(out.fileno(), *owner)
            os.fchmod(out.fileno(), mode)
            os.fsync(out.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def launcher(script):
    target = str(PKG / "deploy/production" / script)
    return ("#!/usr/bin/python3\nimport os, sys\n"
            "os.execv('/usr/bin/python3', ['/usr/bin/python3', '-B', '-E', '-s', "
            + repr(target) + "] + sys.argv[1:])\n").encode()


def forced_path(home, base, expected):
    # Read the existing backup key's command without emitting the key or editing
    # any authorized_keys option. Only the deployed helper itself is replaced.
    matches = []
    for line in (home / ".ssh/authorized_keys").read_text().splitlines():
        if line.lstrip().startswith("#"):
            continue
        key = re.search(r"(?:^|\s)(ssh-ed25519|ssh-rsa|ecdsa-[^\s]+)\s+([A-Za-z0-9+/=]+)(?:\s|$)", line)
        if not key or digest(base64.b64decode(key[2], validate=True)) != expected:
            continue
        options = line[:key.start()].strip()
        command = re.search(r'(?:^|,)command="([^"\\]+)"(?:,|$)', options)
        origin = re.search(r'(?:^|,)from="([^"]+)"(?:,|$)', options)
        if not command or not origin or origin[1] not in ("10.23.52.152", "10.23.52.152/32"):
            end("Existing backup key must retain its forced command and single coordinator source")
        argv = shlex.split(command[1])
        if argv[:1] in (["/usr/bin/python3"], ["python3"]):
            argv = argv[1:]
        if len(argv) != 1:
            end("Unsupported protected backup helper command; use its explicitly confirmed path")
        path = Path(argv[0])
        if (not path.is_absolute() or path.parent not in {DEST, base / "ops"}
                or not re.fullmatch(r"[a-zA-Z0-9._-]*backup[a-zA-Z0-9._-]*", path.name)):
            end("Unexpected existing backup helper path")
        matches.append(path)
    if len(matches) != 1:
        end("Expected exactly one existing matching production backup key")
    return matches[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", choices=HOSTS, required=True)
    args = parser.parse_args()
    if os.geteuid() != 0:
        end("Install as root on the selected production node")
    os.umask(0o022)
    user, ip = HOSTS[args.host]
    account = pwd.getpwnam(user)
    home = Path(account.pw_dir)
    base = home / "env/infrapro"
    if json.loads((base / "config/environment.json").read_text())["ip"] != ip:
        end("The requested host does not match the existing production installation")
    meta = json.loads((SRC / "package.json").read_text())
    manifest = {}
    for line in (SRC / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        value = Path(name)
        if value.is_absolute() or ".." in value.parts or name in manifest or not re.fullmatch("[0-9a-f]{64}", expected):
            end("Invalid payload inventory")
        if (SRC / name).is_symlink() or digest((SRC / name).read_bytes()) != expected:
            end("Payload changed: " + name)
        manifest[name] = expected
    destination = DEST / "infrapro-production-backup" if args.host == "152" else forced_path(home, base, meta["legacy_authorized_key_sha256"])
    if destination.is_symlink() or not destination.is_file():
        end("Expected to preserve an existing regular backup entry: " + str(destination))
    destinations = {destination: launcher("production-backup.py" if args.host == "152" else "backup-node.py")}
    if args.host == "152":
        lock = (base / "run/production-backup.lock").open("a")
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        destinations[DEST / "infrapro-architecture-restore"] = launcher("architecture-restore.py")
    archive = Path("/var/backups/infrapro-checkpoint-tools") / meta["release"] / args.host
    archive.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(archive, 0o700)
    preserved = {}
    for target in destinations:
        if target.is_symlink():
            end("Refusing symlink: " + str(target))
        if target.exists():
            original = archive / ("original-" + target.name)
            if not original.exists():
                shutil.copy2(target, original)
            preserved[str(target)] = {"file": str(original), "sha256": digest(original.read_bytes())}
    for name in [*manifest, "SHA256SUMS"]:
        target = PKG / name
        target.parent.mkdir(parents=True, exist_ok=True, mode=0o755)
        put(target, (SRC / name).read_bytes(), 0o644)
    if args.host == "152":
        # Only the backup administrator's status/epoch CLI is given this file.
        # The legacy workers keep their existing service environments.
        architecture = base / "config/architecture"
        if not architecture.exists():
            architecture.mkdir(mode=0o700)
            os.chown(architecture, account.pw_uid, account.pw_gid)
        path = architecture / "maintenance-events.json"
        if path.is_symlink():
            end("Unexpected symlink at the private event maintenance configuration")
        if path.is_file():
            existing = json.loads(path.read_text())
            if existing.get("mode") != "pg" or not re.fullmatch("[a-z][a-z0-9_]{0,31}", existing.get("environment", "")):
                end("Existing maintenance event configuration differs from production PG mode")
        else:
            put(path, b'{"mode":"pg","environment":"production"}\n', 0o600, (account.pw_uid, account.pw_gid))
    for target, body in destinations.items():
        put(target, body, 0o755)
    summary = {"host": args.host, "time": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "private_rollback": preserved, "entrypoints": [str(p) for p in destinations],
               "tools_sha256": digest((SRC / "SHA256SUMS").read_bytes()), "root_directory": str(PKG)}
    put(archive / "install.json", (json.dumps(summary, indent=2) + "\n").encode(), 0o600)
    print(json.dumps({k: summary[k] for k in ("host", "entrypoints", "tools_sha256", "root_directory")}))


if __name__ == "__main__":
    main()
