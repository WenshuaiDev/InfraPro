"""Private provenance for the four existing native production nodes."""

import io
import json
import os
from pathlib import Path
import pwd
import stat
import tarfile

from s3_archive import file_hash


PACKAGE = Path(__file__).resolve().parents[2]


def read(path):
    return json.loads(path.read_text())


def production_files(base):
    settings = read(PACKAGE / "package.json")
    host = read(base / "config/environment.json")["ip"]
    release = read(base / "config/release.json")["release"]
    profile = {
        "ip": host, "application_release": release, "backup_tools_source_sha256": settings["application_source_sha256"],
        "schema": settings["schema"], "node_archive": ["config", "units", "ops"], "configuration": {},
    }
    config = base / "config"
    for path in sorted(config.rglob("*")):
        if not path.is_file():
            continue
        label = str(path.relative_to(base))
        info = path.stat()
        if path.is_symlink():
            # The original node tar preserves symlinks. Secret material outside
            # the archived tree must be supplied separately before entering a freeze.
            target = path.resolve()
            if config.resolve() not in target.parents:
                if path.suffix in (".key", ".creds") or path.name in ("key", "mfa-keyring.json"):
                    raise ValueError("Private key link leaves the archived configuration: " + label)
                profile["configuration"][label] = {"link": os.readlink(path), "archived_as": "symlink"}
                continue
        profile["configuration"][label] = {
            "bytes": info.st_size, "mode": oct(stat.S_IMODE(info.st_mode)), "uid": info.st_uid,
            "gid": info.st_gid, "sha256": file_hash(path),
        }
    profile["tls_private_keys"] = sorted(k for k in profile["configuration"] if k.startswith("config/tls/") and k.endswith(".key"))
    if host != "10.23.52.152":
        return profile
    if release != settings["release"]:
        raise ValueError("Application release and installed checkpoint tools differ")
    app = base / "releases" / release
    upstream = read(app / "release.json")
    if (upstream.get("schema") != 59 or upstream.get("application_source_sha256") != settings["application_source_sha256"]
            or file_hash(app / "release.json") != settings["release_manifest_sha256"]):
        raise ValueError("The production application release manifest differs from the selected release")
    for name, expected in settings["required_binaries"].items():
        program = app / "bin" / name
        if not program.is_file() or not os.access(program, os.X_OK) or file_hash(program) != expected:
            raise ValueError("Checkpoint executable does not match the selected release: " + name)
    key = config / "app/mfa-keyring.json"
    for cfgname in ("api", "maintenance"):
        if read(config / "app" / (cfgname + ".json")).get("mfa_keyring_file") != str(key):
            raise ValueError("MFA keyring differs between the API, maintenance and production checkpoint")
    if key.is_symlink() or str(key.relative_to(base)) not in profile["configuration"] or key.stat().st_uid != pwd.getpwnam("uadmin").pw_uid or stat.S_IMODE(key.stat().st_mode) != 0o600:
        raise ValueError("Expected existing uadmin-owned 0600 MFA keyring inside the archived configuration")
    keys = read(key)
    versions = [entry["id"] for entry in keys["keys"]]
    if keys.get("format_version") != 1 or keys["active_key_id"] not in versions or len(set(versions)) != len(versions):
        raise ValueError("MFA keyring does not contain its active key version")
    event_file = config / "architecture/maintenance-events.json"
    if read(event_file).get("mode") != "pg":
        raise ValueError("This native compatibility release uses PostgreSQL event maintenance")
    ssh_key = "config/backup-access/key"
    ssh_info = profile["configuration"].get(ssh_key, {})
    if "sha256" not in ssh_info or int(ssh_info["mode"], 8) & 0o077:
        raise ValueError("The existing backup SSH identity must be private and present in the node archive")
    site = base / "releases" / settings["site_release"]
    if not site.is_dir() or site.is_symlink():
        raise ValueError("The site release containing the console and live parser package is missing")
    parser = site / "parser-package"
    html = [p for p in site.rglob("index.html") if "console" in p.relative_to(site).parts]
    if not html or not (parser / "catalog.json").is_file() or not (parser / "ingestion-capabilities.json").is_file():
        raise ValueError("The deployed site console or parser release is absent")
    profile.update({
        "node_archive": ["config", "units", "ops", "releases"],
        "mfa": {"path": str(key.relative_to(base)), "active_key_id": keys["active_key_id"], "key_ids": versions,
                "sha256": file_hash(key), "mode": "0o600"},
        "backup_ssh_identity": {"path": ssh_key, **ssh_info},
        "current_release_manifest": file_hash(app / "release.json"),
        "site_release": settings["site_release"],
        "site_entrypoints": {str(p.relative_to(base)): file_hash(p) for p in [*html, parser / "catalog.json", parser / "ingestion-capabilities.json"]},
        "schema_59_files": {path: expected for path, expected in settings["upstream_files"].items() if path.endswith(".sql")},
        "events": {"mode": "pg", "checkpoint": "event-watermarks.json"},
        "custody": {"business": "inner-receipts.json", "edge": "node-151.tar.gz:relay-manifest.json"},
        "display": "display-files.json",
    })
    return profile


def archive_provenance(tar, profile):
    data = json.dumps(profile, ensure_ascii=False, sort_keys=True, indent=2).encode() + b"\n"
    member = tarfile.TarInfo("site-checkpoint-materials.json")
    member.mode, member.size = 0o600, len(data)
    tar.addfile(member, io.BytesIO(data))
    # The checkpoint must carry the working restore CLI and its sibling DCL,
    # including our node adapter, independently of future system installations.
    for line in (PACKAGE / "SHA256SUMS").read_text().splitlines():
        expected, relative = line.split("  ", 1)
        file = PACKAGE / relative
        if file_hash(file) != expected:
            raise ValueError("Installed backup tool changed: " + relative)
        tar.add(file, arcname="installed-checkpoint-tools/" + relative)
    tar.add(PACKAGE / "SHA256SUMS", arcname="installed-checkpoint-tools/SHA256SUMS")
